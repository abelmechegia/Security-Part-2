#!/usr/bin/bash

# This is the file that is defined and monitored in my home directory
DIR="/home/abel/user.sh"

# File to store the hash of the directory
HASH_FILE="/home/abel/abel_hash.txt"

# Calculate the current hash of the user.sh file in my home directory
current_hash=$(find "$DIR" -type f -exec sha256sum {} + | sha256sum | awk '{print $1}')

# If the hash file doesn't exist, this will create the hash file with the current hash
if [ ! -f "$HASH_FILE" ]; then
    echo "$current_hash" > "$HASH_FILE"
    exit 0
fi

# Read the previously stored hash and compare with the current hash
stored_hash=$(cat "$HASH_FILE")

# If the hashes differ, this will update the hash file and notify about the changes
if [ "$current_hash" != "$stored_hash" ]; then
    echo "$current_hash" > "$HASH_FILE"
    echo "Changes detected!"
fi
