#!/usr/bin/bash

# This is the file that is defined and monitored in my home directory
DIR="/home/abel/user.sh"

# This is the text file that stores the hash in my directory
HASH_FILE="/home/abel/abel_hash.txt"

# This calculates the current hash of the user.sh file in my home directory
current_hash=$(find "$DIR" -type f -exec sha256sum {} + | sha256sum | awk '{print $1}')

# If the hash file doesn't exist, this will create the hash file with the current hash
if [ ! -f "$HASH_FILE" ]; then
    printf "%s" "$current_hash" > "$HASH_FILE"
    exit 0
fi

# This reads the previously stored hash and compares it with the current hash
stored_hash=$(cat "$HASH_FILE")

# This will update the hash file if the hashes are different
if [ "$current_hash" != "$stored_hash" ]; then
    printf "%s" "$current_hash" > "$HASH_FILE"
fi
