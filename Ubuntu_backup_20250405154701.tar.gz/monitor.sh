#!/bin/bash

# Monitor my home directry
WATCH_DIR="/"

# Log file
LOG_FILE="/var/log/file_monitor.log"

# Monitor hidden files and root executables
inotifywait -m -r -e modify,move,create,delete --format '%w%f' $WATCH_DIR | while read file
do
    # Check if file is hidden (starts with .) or owned by root
    if [[ "$file" =~ ^/.* || "$(stat -c %U "$file")" == "root" ]]; then
        # Log the change: file, user, timestamp, and action
        user=$(stat -c '%U' "$file")
        timestamp=$(date "+%Y-%m-%d %H:%M:%S")
        echo "$timestamp - File: $file, User: $user, Action: Changed" >> $LOG_FILE
    fi
done
