#!/bin/bash
#jnjhijijij
for user in ls /home
do
    echo -n "$user  ";last $user | head -1  | awk  '[print substr($0,40)]'
done
