#!/usr/bin/bash

# Define a variable for the user
USER="sam"

# Print any logins between midnight to 6am
last -i | awk '$4 ~ /^0|^1|^2|^3|^4|^5/ {print $3, $2}' | sort | uniq -c | sort -nr

#Prints the login for the user sam
last -i | grep "$USER" | awk '{print $3, $2, $5, $6}'

#Print the logged in user IP address
who | grep "$USER" | awk '{print $1, $NF}'

# Print failed logins attempts
lastb -i | awk '{print $3, $2}' | sort | uniq -c | sort -nr

# Print repeated failed login attempts more than 5 times
lastb -i | awk '{print $3, $2}' | sort | uniq -c | awk '$1 > 5'

