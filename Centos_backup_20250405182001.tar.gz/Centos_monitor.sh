#!/usr/bin/bash

# The etc directory that is being monitored
WATCH_DIR="/etc"

# This is where the log file is being saved
LOG_FILE="/var/log/file_monitor.log"

# This is to monitor the hidden files and root executables
inotifywait -m -r -e modify,move,create,delete --format '%w%f' $WATCH_DIR | while read file
do
    # This is to check if file is hidden (starts with .) or owned by root
    if [[ "$file" =~ ^/.* || "$(stat -c %U "$file")" == "root" ]]; then
        # This is to log the change in file, user, timestamp, and what action is performed then printed
        user=$(stat -c '%U' "$file")
        timestamp=$(date "+%Y-%m-%d %H:%M:%S")
        printf "%s - File: %s, User: %s, Action: Changed\n" "$timestamp" "$file" "$user" >> "$LOG_FILE"
    fi
done
